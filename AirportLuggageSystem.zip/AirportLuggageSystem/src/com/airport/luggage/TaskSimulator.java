package com.airport.luggage;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class TaskSimulator {
    private final LogService logs;

    public TaskSimulator(LogService logs) {
        this.logs = logs;
    }

    public void simulateVehicle(String id) throws IOException {
        String payload = "EVENT=Pickup|BAG=BG445612|GATE=A14";
        byte[] bytes = payload.getBytes(StandardCharsets.UTF_8);

        try (ByteArrayInputStream in = new ByteArrayInputStream(bytes)) {
            String decoded = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            logs.append(LogRecord.now("vehicles", id, "Pickup", decoded));
        }
    }

    public void simulateCharger(String id, int soc) throws IOException {
        String payload = "EVENT=Charge|SOC=" + soc + "%";
        logs.append(LogRecord.now("chargers", id, "Charge", payload));
    }

    public void simulateSystemHealth(String msg) throws IOException {
        logs.append(LogRecord.now("system", "SYS", "Health", msg));
    }
}
