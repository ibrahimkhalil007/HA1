package com.airport.luggage;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class FileManager {

    public void move(Path src, Path dst) throws IOException {
        Files.createDirectories(dst.getParent());
        Files.move(src, dst, StandardCopyOption.REPLACE_EXISTING);
        System.out.println("Moved file: " + src + " → " + dst);
    }

    public void delete(Path file) throws IOException {
        Files.deleteIfExists(file);
        System.out.println("Deleted file: " + file);
    }

    public Path archiveDaily(Path logsRoot, LocalDate date, Path archiveDir) throws IOException {
        Files.createDirectories(archiveDir);
        Path zip = archiveDir.resolve("logs-" + date + ".zip");

        try (ZipOutputStream zos = new ZipOutputStream(Files.newOutputStream(zip))) {
            Files.walk(logsRoot)
                    .filter(p -> Files.isRegularFile(p) && p.getFileName().toString().equals(date + ".log"))
                    .forEach(p -> {
                        try {
                            ZipEntry entry = new ZipEntry(logsRoot.relativize(p).toString());
                            zos.putNextEntry(entry);
                            Files.copy(p, zos);
                            zos.closeEntry();
                        } catch (IOException e) {
                            throw new UncheckedIOException(e);
                        }
                    });
        }

        System.out.println("Archived logs to: " + zip);
        return zip;
    }
}
