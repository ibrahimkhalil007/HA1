package com.airport.luggage;

import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;

public class Main {
    public static void main(String[] args) throws Exception {
        Path root = Path.of("data");
        LogService logs = new LogService(root);
        TaskSimulator sim = new TaskSimulator(logs);
        FileManager fm = new FileManager();
        RegexSearch rs = new RegexSearch();

        System.out.println("=== Airport Luggage Smart System ===");
        System.out.println("Generating log files...");

        // Simulate some log events
        sim.simulateVehicle("V101");
        sim.simulateVehicle("V202");
        sim.simulateCharger("C17", 82);
        sim.simulateSystemHealth("All systems operational.");

        LocalDate today = LocalDate.now();

        // Read log example
        Path v101Log = logs.pathFor("vehicles", "V101", today);
        System.out.println("\nReading log file: " + v101Log);
        List<String> lines = logs.read(v101Log);
        lines.forEach(System.out::println);

        // Regex example
        System.out.println("\nFiltering 'Pickup' events with Regex...");
        List<String> pickups = rs.grep(v101Log, "Pickup");
        pickups.forEach(System.out::println);

        // Archive today's logs
        fm.archiveDaily(root.resolve("logs"), today, root.resolve("archive"));

        System.out.println("\nAll tasks complete.");
        System.out.println("===============================");
    }
}
