package com.airport.luggage;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public record LogRecord(
        ZonedDateTime timestamp,
        String group,           // vehicles | chargers | system
        String equipmentId,
        String event,
        String details) {

    public static LogRecord now(String group, String equipmentId, String event, String details) {
        return new LogRecord(ZonedDateTime.now(), group, equipmentId, event, details);
    }

    public String formatLine() {
        return "%s | EQUIP=%s | EVENT=%s | %s"
                .formatted(timestamp.format(DateTimeFormatter.ISO_ZONED_DATE_TIME),
                           equipmentId, event, details);
    }
}
