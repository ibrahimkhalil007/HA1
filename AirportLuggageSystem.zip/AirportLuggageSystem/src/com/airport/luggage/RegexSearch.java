package com.airport.luggage;

import java.io.IOException;
import java.nio.file.*;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Stream;

public class RegexSearch {

    public List<Path> findLogs(Path root, String equipmentOrDate) throws IOException {
        Pattern datePat = Pattern.compile("\\d{4}-\\d{2}-\\d{2}");
        boolean looksLikeDate = datePat.matcher(equipmentOrDate).matches();

        try (Stream<Path> paths = Files.walk(root.resolve("logs"))) {
            return paths.filter(Files::isRegularFile).filter(p -> {
                String name = p.getFileName().toString();
                if (looksLikeDate) return name.equals(equipmentOrDate + ".log");
                return p.toString().contains("/" + equipmentOrDate + "/");
            }).toList();
        }
    }

    public List<String> grep(Path logFile, String regex) throws IOException {
        Pattern pattern = Pattern.compile(regex);
        try (var reader = Files.newBufferedReader(logFile)) {
            return reader.lines().filter(line -> pattern.matcher(line).find()).toList();
        }
    }
}
