package com.airport.luggage;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.List;

public class LogService {
    private final Path root;

    public LogService(Path root) {
        this.root = root;
    }

    public Path pathFor(String group, String equipmentId, LocalDate date) {
        Path dir = switch (group) {
            case "vehicles" -> root.resolve("logs/vehicles").resolve(equipmentId);
            case "chargers" -> root.resolve("logs/chargers").resolve(equipmentId);
            case "system" -> root.resolve("logs/system");
            default -> throw new IllegalArgumentException("Unknown group: " + group);
        };
        return dir.resolve(date + ".log");
    }

    public void append(LogRecord rec) throws IOException {
        Path p = pathFor(rec.group(), rec.equipmentId(), rec.timestamp().toLocalDate());
        Files.createDirectories(p.getParent());
        try (BufferedWriter w = Files.newBufferedWriter(p, StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
            w.write(rec.formatLine());
            w.newLine();
        }
    }

    public List<String> read(Path logFile) throws IOException {
        try (BufferedReader r = Files.newBufferedReader(logFile)) {
            return r.lines().toList();
        }
    }
}
